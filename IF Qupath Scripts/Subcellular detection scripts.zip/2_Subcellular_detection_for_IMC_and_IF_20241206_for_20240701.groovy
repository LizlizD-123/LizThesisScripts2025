    //1. Subcellular Detection of IFNg spots
    // Below will run the subcelluar detection to detect IFNg spots
    // Can change threshold cut offs (particularly the expected/average size of the spots) depending on images if needs adjusting
    //But! once decided what the expected size is, keep consistent
    //Adjust the flurorescence cut off for each experiment, can vary between batches
    // date in the name of the script refelcts which samples to run the detection for (matches the experiment date). The cut off has been adjusted for the batch.
    //Elizabeth Dunn 20231122
    
//set channel 2 threshold to match experiment cut offs. Use comparison between no probe, positive probe, and IFNg probe
//20240917
selectCells();
runPlugin('qupath.imagej.detect.cells.SubcellularDetection', '{ "detection[Channel 1]":-1.0,"detection[Channel 2]":1360.0,"detection[Channel 3]":-1.0,"detection[Channel 4]":-1.0,"doSmoothing":true,"splitByIntensity":true,"splitByShape":true,"spotSizeMicrons":2.7,"minSpotSizeMicrons":1.4,"maxSpotSizeMicrons":4.5,"includeClusters":true}')
println 'Subcellular Detection script done'

