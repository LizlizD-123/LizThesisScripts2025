20250813 Elizabeth Dunn

I made these scripts for use in a batch IMC project in Qupath. Some I wrote myself and others adapted from image.sc forum posts


1. 20250309 renaming IMC images for batch no metal names. Renames the channel names to suit

2. 20250110 image alignment warpy with loop for multiple warpy: Run this on the IMC project to move IMC ROIs to IF. Runs a loop so if you have multiple ROIs (IMC), they will all end up on the IF image, ready for segmenting with below script. Also run to pull the segmented cells back onto the IMC image, but make sure to delete the cells not on the IMC image! Select the parent annotation of the cells to delete, and delete the parent along with the cells. Commented out adding intensity measurements
3. 20250121 nuceli detection IF 20250423: This is based off my IF project detection parameters. Run this on IF images for segmentation.
4. 20250308 detecting adipocytes: run on IMC image to detect adipocytes. Need copy of the model listed in the script to run. I have it saved in my labarchives.
5. 20250309 adding measurements: run on IMC images after all the cells (and adipocyes) and compartments are in place to add measurements

6. 20250309 exporting cells geojson file: export a copy of the cells after they are on the image! Essential!
7. 20250308 exporting adipocyte geo json file: export copy of adipocytes
8. 20250308 exporting compartment annotation geojson: export the IMC compartment.
9. 20250308 import adipocyte. imports the masks from the export script
10. 20250309 import cells. Imports the masks from the export script
11. 20250308 import compartment annotation geojson. Import the compartment masks from the export script
12. 20250429 exporting cell mask for mantis: exports the mask in the format needed for import with mantis
13. 20250430 exporting OME-TIFF with correct names. exports the images so they can be used by mantis

14. 20250522 import csv for classification. Imports a csv of clustered cells. Qupath<->R. allows for the clusters made in R to be imported back into Quapth for viewing... This script very inefficient so takes a while. Could be made more efficient if a single csv for each image exported from R... Instead I export a giant csv and import that.
